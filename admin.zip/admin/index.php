<?php 
include 'view/header.php';
include 'view/main.php';
include 'view/footer.php';
?>